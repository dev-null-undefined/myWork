﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Zlomek
{
    class Vector
    {
        private int _v1;
        private int _v2;
        private int _v3;
        public Vector(int v1,int v2,int v3)
        {
            _v1 = v1;
            _v2 = v2;
            _v3 = v3;
        }

        public override bool Equals(object obj)
        {
            return obj is Vector vector && this==vector;
        }

        public override int GetHashCode()
        {
            var hashCode = -486212086;
            hashCode = hashCode * -1521134295 + _v1.GetHashCode();
            hashCode = hashCode * -1521134295 + _v2.GetHashCode();
            hashCode = hashCode * -1521134295 + _v3.GetHashCode();
            return hashCode;
        }
        public static implicit operator double(Vector a) => Math.Sqrt(Math.Pow(a._v1, 2) + Math.Pow(a._v2, 2) + Math.Pow(a._v3, 2));
        public static Vector operator +(Vector a, Vector b) => new Vector(a._v1 + b._v1, a._v2 + b._v2, a._v3 + b._v3);
        public static Vector operator *(Vector a, Vector b) => new Vector(a._v2 * b._v3 - b._v2 * a._v3, a._v3 * b._v1 - b._v3 * a._v1, a._v1 * b._v2 - b._v1 * a._v2);

        public static Vector operator -(Vector a, Vector b) => new Vector(a._v1 - b._v1, a._v2 - b._v2, a._v3 - b._v3);

        public static Vector ScalarniSoucin(Vector a, Vector b) => new Vector(a._v1 * b._v1, a._v2 * b._v2, a._v3 * b._v3);

        public static bool operator ==(Vector a, Vector b) => a._v1==b._v1&&a._v2==b._v2&&a._v3==b._v3;

        public static bool operator !=(Vector a, Vector b) => !(a == b);



    }
}
