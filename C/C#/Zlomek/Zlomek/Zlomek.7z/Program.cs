﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Zlomek
{
    class Program
    {
        static void Main(string[] args)
        {
            Zlomek a = new Zlomek(4 , 5);

            Zlomek b = new Zlomek(9, 7);
            
            
        }
    }
}
